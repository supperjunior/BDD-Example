package gov.tim.maps;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;

import org.openqa.selenium.WebElement;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import gov.tim.users.WikiSteps;
import gov.tim.util.RespositoryParser;
import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Steps;


public class wikiMap extends PageObject{
	
	@Steps WikiSteps wikiSteps;
	private static RespositoryParser parser =new RespositoryParser("ObjectRepo.properties") ;
	
	
	@Given("i have naviagted into wikiPage")
	public void loggedIntoWikiPage() throws IOException{
		open();
	}
		

	@When("i search for '(.*)' using search bar")
	public void search(String fruit) throws IOException
	{
		
		WebElement searchText = getDriver().findElement(parser.getbjectLocator("searchItem"));
		WebElement searchButton = getDriver().findElement(parser.getbjectLocator("srchButton"));
		searchText.sendKeys(fruit);
		searchButton.click();
		 
	
	}
	@Then("i should be navigated to '(.*)' page")
	public void verifyThePage(String title)
	{
	      String titleFromPage= getDriver().findElement(parser.getbjectLocator("title")).getText();
		  assertThat(titleFromPage).isEqualToIgnoringCase(title);
		  
	}
	

	
	

}
