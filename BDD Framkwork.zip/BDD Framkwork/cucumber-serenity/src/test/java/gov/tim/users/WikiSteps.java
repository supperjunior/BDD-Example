package gov.tim.users;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;

import org.openqa.selenium.WebElement;

import gov.tim.util.RespositoryParser;
import net.thucydides.core.steps.ScenarioSteps;

public class WikiSteps extends ScenarioSteps {
 
	private static final long serialVersionUID = 1L;
	private static RespositoryParser parser ;
	
	
	public void searchForFruit(String fruit) throws IOException {
		parser = new RespositoryParser("ObjectRepo.properties");
		 WebElement searchText = getDriver().findElement(parser.getbjectLocator("searchItem"));
		 WebElement searchButton =  getDriver().findElement(parser.getbjectLocator("searchButton"));
		 searchButton.click();
		 
		 searchText.sendKeys(fruit);

	}

	public void verifyThePage(String title) {
		WebElement titleFromPage = getDriver().findElement(parser.getbjectLocator("searchButton"));
		assertThat(titleFromPage).isEqualTo(title);
		
	}

}
